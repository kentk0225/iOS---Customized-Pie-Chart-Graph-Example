//
//  Config.m


#define M_PI        3.14159265358979323846264338327950288
#define DEGREES_RADIANS(angle) ((angle) / 180.0 * M_PI)