//
//  MainViewController.h
//  SchMuck
//
//  Created by Mac on 30/3/15.
//  Copyright (c) 2015 Mac. All rights reserved.
//


#import "SHPieChartView.h"
#import "CoreTextArcView.h"

@interface MainViewController : UIViewController

@property (nonatomic, strong) IBOutlet UIView *mainView;

@end
