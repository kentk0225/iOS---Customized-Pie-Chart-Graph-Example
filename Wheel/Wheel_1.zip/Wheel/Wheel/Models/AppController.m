//
//  AppController.m


#import "AppController.h"

static AppController *_appController;

@implementation AppController

+ (AppController *)sharedInstance {
    static dispatch_once_t predicate;
    if (_appController == nil) {
        dispatch_once(&predicate, ^{
            _appController = [[AppController alloc] init];
        });
    }
    return _appController;
}

- (id)init {
    self = [super init];
    if (self) {
        
        // Sample Value for Category / Components / Rating
        NSMutableDictionary *cat1 = [@{
                                       @"title" : @"Category1",
                                       @"color" : @"c3986b",
                                       @"components" : [
                                                        @[
                                                          [@{
                                                             @"title" : @"Comp1",
                                                             @"color" : @"a87c4f",
                                                             @"rating" : @"3"
                                                             } mutableCopy],
                                                          [@{
                                                             @"title" : @"Comp2",
                                                             @"color" : @"a87c4f",
                                                             @"rating" : @"2"
                                                             } mutableCopy],
                                                          [@{
                                                             @"title" : @"Comp3",
                                                             @"color" : @"a87c4f",
                                                             @"rating" : @"5"
                                                             } mutableCopy]
                                                          ] mutableCopy
                                                        ]
                                       } mutableCopy];
        
        NSMutableDictionary *cat2 = [@{
                                       @"title" : @"Master Photoshop",
                                       @"color" : @"c3986b",
                                       @"components" : [
                                                        @[
                                                          [@{
                                                             @"title" : @"Layer",
                                                             @"color" : @"a87c4f",
                                                             @"rating" : @"1"
                                                             } mutableCopy],
                                                          [@{
                                                             @"title" : @"Visual",
                                                             @"color" : @"a87c4f",
                                                             @"rating" : @"5"
                                                             } mutableCopy],
                                                          [@{
                                                             @"title" : @"Typography",
                                                             @"color" : @"a87c4f",
                                                             @"rating" : @"2"
                                                             } mutableCopy]
                                                          ] mutableCopy
                                                        ]
                                       } mutableCopy];
        
        NSMutableDictionary *cat3 = [@{
                                       @"title" : @"Category3",
                                       @"color" : @"c3986b",
                                       @"components" : [
                                                        @[
                                                          [@{
                                                             @"title" : @"Comp1",
                                                             @"color" : @"a87c4f",
                                                             @"rating" : @"4"
                                                             } mutableCopy],
                                                          [@{
                                                             @"title" : @"Comp2",
                                                             @"color" : @"a87c4f",
                                                             @"rating" : @"5"
                                                             } mutableCopy]
                                                          ] mutableCopy
                                                        ]
                                       } mutableCopy];
        
        NSMutableDictionary *cat4 = [@{
                                       @"title" : @"Category4",
                                       @"color" : @"c3986b",
                                       @"components" : [
                                                        @[
                                                          [@{
                                                             @"title" : @"Comp1",
                                                             @"color" : @"a87c4f",
                                                             @"rating" : @"3"
                                                             } mutableCopy],
                                                          [@{
                                                             @"title" : @"Comp2",
                                                             @"color" : @"a87c4f",
                                                             @"rating" : @"3"
                                                             } mutableCopy],
                                                          [@{
                                                             @"title" : @"Comp3",
                                                             @"color" : @"a87c4f",
                                                             @"rating" : @"5"
                                                             } mutableCopy]
                                                          ] mutableCopy
                                                        ]
                                       } mutableCopy];
        
        NSMutableDictionary *cat5 = [@{
                                       @"title" : @"Category5",
                                       @"color" : @"c3986b",
                                       @"components" : [
                                                        @[
                                                          [@{
                                                             @"title" : @"Comp1",
                                                             @"color" : @"a87c4f",
                                                             @"rating" : @"3"
                                                             } mutableCopy],
                                                          [@{
                                                             @"title" : @"Comp2",
                                                             @"color" : @"a87c4f",
                                                             @"rating" : @"2"
                                                             } mutableCopy],
                                                          [@{
                                                             @"title" : @"Comp3",
                                                             @"color" : @"a87c4f",
                                                             @"rating" : @"1"
                                                             } mutableCopy],
                                                          [@{
                                                             @"title" : @"Comp4",
                                                             @"color" : @"a87c4f",
                                                             @"rating" : @"4"
                                                             } mutableCopy]
                                                          ] mutableCopy
                                                        ]
                                       } mutableCopy];
        
        NSMutableDictionary *cat6 = [@{
                                       @"title" : @"Category6",
                                       @"color" : @"c3986b",
                                       @"components" : [
                                                        @[
                                                          [@{
                                                             @"title" : @"Comp1",
                                                             @"color" : @"a87c4f",
                                                             @"rating" : @"5"
                                                             } mutableCopy],
                                                          [@{
                                                             @"title" : @"Comp2",
                                                             @"color" : @"a87c4f",
                                                             @"rating" : @"3"
                                                             } mutableCopy]
                                                          ] mutableCopy
                                                        ]
                                       } mutableCopy];
        
        _categories = [[NSMutableArray alloc] init];
        _categories = [@[cat1, cat2, cat3, cat4, cat5, cat6] mutableCopy];
    }
    return self;
}

@end
