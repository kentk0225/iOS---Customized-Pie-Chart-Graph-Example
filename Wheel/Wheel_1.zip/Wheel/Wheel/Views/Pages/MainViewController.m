//
//  MainViewController.m
//  SchMuck
//
//  Created by Mac on 30/3/15.
//  Copyright (c) 2015 Mac. All rights reserved.
//

#import "MainViewController.h"


@interface MainViewController () {
    NSMutableArray *categories;
    NSInteger totalComponentsCount, totalCategoriesCount;
    
    CGRect mainFrame;
    float angleMargin, ratioRadiusMargin, radiusMargin;
    float ratioArcRadiusCategory, ratioArcRadiusComponent, ratioArcRadiusGraph, ratioArcRadiusGraphOuterMargin, ratioArcRadiusCenter;
    float radiusTotal, radiusCategory, radiusComponent, radiusGraph, radiusCenter;
    int maxRating;
    NSString *colorCenter, *colorGraphBackground, *colorGraph;
}

@end

@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    [self initValue];
    NSLog(@"%@", categories);
//
//    SHPieChartView *concentricPieChart = [[SHPieChartView alloc] initWithFrame:CGRectMake(0, 0, 400, 400)];
//    concentricPieChart.chartBackgroundColor = [commonUtils getUIColorFromHexString:@"DEDEDE"];
//    
//    concentricPieChart.isConcentric = YES;
//    concentricPieChart.concentricRadius = 70;
//    concentricPieChart.concentricColor = [commonUtils getUIColorFromHexString:@"54525C"];
//    
//    [concentricPieChart addAngleValue:0.40 andColor:[UIColor redColor]];
//    
//    [self.mainView addSubview:concentricPieChart];

}

- (void)viewDidLayoutSubviews {
    [self drawArcCategories];
    [self drawArcComponents];
    [self drawArcGraphBackground];
    [self drawArcCenter];
    [self drawArcGraph];
}

#pragma init settings
- (void)initValue {
    
    categories = [[NSMutableArray alloc] init];
    categories = appController.categories;
    
    totalCategoriesCount = [categories count];
    totalComponentsCount = 0;
    for(NSMutableDictionary *dicCategory in categories) {
        int componentsCount = [[dicCategory objectForKey:@"components"] count];
        totalComponentsCount += componentsCount;
        [dicCategory setObject:[NSString stringWithFormat:@"%d", componentsCount] forKey:@"componentsCount"];
    }
    
    mainFrame = self.mainView.frame;
    
    // Ratio values for each circle radius compared to entire frame radius
    // You can customize these values
    
    maxRating = 5;
    
    angleMargin = 0.001;
    ratioRadiusMargin = 0.00001f;

    ratioArcRadiusCategory = 0.13;
    ratioArcRadiusComponent = 0.14;
    ratioArcRadiusCenter = 0.11;
    ratioArcRadiusGraphOuterMargin = 0.08;
    ratioArcRadiusGraph = ratioArcRadiusCenter * maxRating;
    //ratioArcRadiusGraph = 1.0 - ratioArcRadiusCategory - ratioArcRadiusComponent - ratioArcRadiusCenter - ratioArcRadiusGraphOuterMargin - (ratioRadiusMargin * 3);
    
    radiusTotal = mainFrame.size.width / 2.0f;
    radiusMargin = radiusTotal * ratioRadiusMargin;
    
    radiusCategory = radiusTotal * (1.0 - ratioRadiusMargin);
    radiusComponent = radiusTotal * (1.0 - ratioArcRadiusCategory - (ratioRadiusMargin * 2));
    //radiusGraph = radiusTotal * (1.0 - ratioArcRadiusCategory - ratioArcRadiusComponent - ratioArcRadiusGraphOuterMargin - (ratioRadiusMargin * 3));
    
    radiusCenter = (float)radiusTotal * ratioArcRadiusCenter;
    radiusGraph = radiusCenter * (float)maxRating;
    
    colorCenter = @"a87c4f";
    colorGraphBackground = @"F9F9F9";
    colorGraph = @"AAAAAA";
    
    
}

#pragma draw Arc
// Category Arc
- (void)drawArcCategories {
    SHPieChartView *chart = [[SHPieChartView alloc] initWithFrame:[commonUtils getCGRectFromRadius:radiusCategory withFormat:mainFrame]];
    chart.chartBackgroundColor = [UIColor whiteColor];
    chart.isConcentric = YES;
    chart.concentricRadius = radiusComponent + radiusMargin;
    chart.concentricColor = [UIColor whiteColor];
    for(NSMutableDictionary *dicCategory in categories) {
        [chart addAngleValue:(([[dicCategory objectForKey:@"componentsCount"] intValue] / (float)totalComponentsCount) - angleMargin) andColor:[commonUtils getUIColorFromHexString:[dicCategory objectForKey:@"color"]]];
        [chart addAngleValue:angleMargin andColor:[UIColor whiteColor]];
        
    }
    [self.mainView addSubview:chart];
}
// Components Arc
- (void)drawArcComponents {
    SHPieChartView *chart = [[SHPieChartView alloc] initWithFrame:[commonUtils getCGRectFromRadius:radiusComponent withFormat:mainFrame]];
    chart.chartBackgroundColor = [UIColor whiteColor];
    chart.isConcentric = YES;
    chart.concentricRadius = radiusGraph + ratioArcRadiusGraphOuterMargin * radiusTotal;
    chart.concentricColor = [UIColor whiteColor];
    for(NSMutableDictionary *dicCategory in categories) {
        NSMutableArray *arrComponents = [[NSMutableArray alloc] init];
        arrComponents = [dicCategory objectForKey:@"components"];
        for(NSMutableDictionary *dicComponent in arrComponents) {
            [chart addAngleValue:((1.0 / (float)totalComponentsCount) - angleMargin) andColor:[commonUtils getUIColorFromHexString:[dicComponent objectForKey:@"color"]]];
            [chart addAngleValue:angleMargin andColor:[UIColor whiteColor]];
        }
    }
    [self.mainView addSubview:chart];
}
// Graph Arc Background
- (void)drawArcGraphBackground {
    int i = 0;
    for(; i < maxRating - 1; i++) {
        float radius = radiusGraph - ((float)i * ((radiusGraph - radiusCenter) / (float)(maxRating - 1)));
        SHPieChartView *chart = [[SHPieChartView alloc] initWithFrame:[commonUtils getCGRectFromRadius:radius + 3.5f withFormat:mainFrame]];
        chart.isConcentric = YES;
        chart.concentricRadius = radius - 3.5f;
        chart.concentricColor = [UIColor whiteColor];
        [chart addAngleValue:1.0 andColor:[commonUtils getUIColorFromHexString:colorGraphBackground]];
        [self.mainView addSubview:chart];
    }
}
// Graph
- (void)drawArcGraph {
    SHPieChartView *chart = [[SHPieChartView alloc] initWithFrame:[commonUtils getCGRectFromRadius:radiusCategory withFormat:mainFrame]];
    chart.isGraph = YES;
    chart.graphColor = [commonUtils getUIColorFromHexString:colorGraph];
    chart.graphCount = totalComponentsCount;
    chart.graphPointRadius = 3.0f;
    chart.graphRadius = radiusCenter - 1.8f;
    chart.graphData = categories;
    [self.mainView addSubview:chart];
}
// Center Circle Arc
- (void)drawArcCenter {
    SHPieChartView *chart = [[SHPieChartView alloc] initWithFrame:[commonUtils getCGRectFromRadius:radiusCenter withFormat:mainFrame]];
    [chart addAngleValue:1.0 andColor:[commonUtils getUIColorFromHexString:colorCenter]];
    [self.mainView addSubview:chart];
}
@end
