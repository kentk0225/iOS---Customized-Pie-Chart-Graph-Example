//
//  CSCoverageArea.m
//
//
//  Created by Marco Brambilla on 26/05/13.
//  Copyright (c) 2013 CommonSense. All rights reserved.
//

#import "CSCoverageArea.h"

@implementation CSCoverageArea

@end
