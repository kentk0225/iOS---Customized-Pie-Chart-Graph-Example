//
//  ViewController.h
//  CSCoverageChartExample
//
//  Created by Marco Brambilla on 27/05/13.
//  Copyright (c) 2013 CommonSense. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CSCoverageChart.h"

@interface ViewController : UIViewController<CSCoverageChartDelegate>

@end
