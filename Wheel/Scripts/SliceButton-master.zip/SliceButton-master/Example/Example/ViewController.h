//
//  ViewController.h
//  Example
//
//  Created by PJ on 2/12/13.
//
//

#import <UIKit/UIKit.h>
#import "SliceButton.h"

@interface ViewController : UIViewController <SliceButtonDelegate>

@end
