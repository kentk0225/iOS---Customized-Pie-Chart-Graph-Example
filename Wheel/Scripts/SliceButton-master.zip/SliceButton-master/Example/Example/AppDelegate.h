//
//  AppDelegate.h
//  Example
//
//  Created by PJ on 2/12/13.
//
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
