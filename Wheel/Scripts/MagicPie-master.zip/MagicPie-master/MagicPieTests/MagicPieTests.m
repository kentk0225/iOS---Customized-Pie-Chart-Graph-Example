//
//  MagicPieTests.m
//  MagicPieTests
//
//  Created by Alexandr on 30.09.13.
//  Copyright (c) 2013 Alexandr Corporation. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface MagicPieTests : XCTestCase
@end

@implementation MagicPieTests


- (void)setUp
{
    [super setUp];
}

- (void)tearDown
{
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
