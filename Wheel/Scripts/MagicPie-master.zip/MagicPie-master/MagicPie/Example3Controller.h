//
//  Example3Controller.h
//  MagicPie
//
//  Created by Alexander on 18.01.14.
//  Copyright (c) 2014 Alexandr Corporation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Example3Controller : UIViewController

@end
