//
//  NSArray+descValues.h
//  MagicPie
//
//  Created by Alexander on 25.12.13.
//  Copyright (c) 2013 Alexandr Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray (descValues)
- (NSString*)descValues;
@end
