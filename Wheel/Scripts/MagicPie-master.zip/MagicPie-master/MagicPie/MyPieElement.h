//
//  MyPieElement.h
//  MagicPie
//
//  Created by Alexander on 31.12.13.
//  Copyright (c) 2013 Alexandr Corporation. All rights reserved.
//

#import "PieElement.h"

@interface MyPieElement : PieElement
@property (nonatomic, strong) NSString* title;
@end
