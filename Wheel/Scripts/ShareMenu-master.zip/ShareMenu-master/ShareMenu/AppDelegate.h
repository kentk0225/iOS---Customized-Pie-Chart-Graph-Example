//
//  AppDelegate.h
//  ShareMenu
//
//  Created by Bhavik on 14/05/14.
//  Copyright (c) 2014 Bhavik. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
