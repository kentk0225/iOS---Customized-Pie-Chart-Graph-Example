//
//  ViewController.h
//  ShareMenu
//
//  Created by Bhavik on 14/05/14.
//  Copyright (c) 2014 Bhavik. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BSShareMenu.h"

@interface ViewController : UIViewController<BSShareMenuDelegate>

@end
